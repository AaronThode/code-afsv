This is a text file explaining the bitbucket repository.
