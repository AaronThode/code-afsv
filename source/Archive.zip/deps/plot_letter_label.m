%function plot_letter_label(charr) 
%function plot_letter_label(charr)
%        text(-0.15,1.1,charr,'units','norm','fontweight','bold','fontsize',14);
%    end
function plot_letter_label(charr)
        text(-0.05,1.10,charr,'units','norm','fontweight','bold','fontsize',12);
    end