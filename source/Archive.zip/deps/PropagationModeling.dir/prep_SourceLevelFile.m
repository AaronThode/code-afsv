clear p TL TLdB
clear extrct Xfft Xsource Xfft B x0
%rplot and zplot describe dimensions of x
%rd=sd;
save([savename '.mat']);

%Note, attenuation set to 0.5 dB/lambda